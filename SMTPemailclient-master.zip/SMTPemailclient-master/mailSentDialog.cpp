#include "stdafx.h"
#include "mailSentDialog.h"

